@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$desk=[Environment]::GetFolderPath('Desktop'); $target=Join-Path $PSScriptRoot 'Launch Oracle Fusion Predictor.bat'; $shortcut=Join-Path $desk 'Oracle Fusion Predictor.lnk'; $shell=New-Object -ComObject WScript.Shell; $lnk=$shell.CreateShortcut($shortcut); $lnk.TargetPath=$target; $lnk.WorkingDirectory=$PSScriptRoot; $lnk.IconLocation='%SystemRoot%\System32\SHELL32.dll,14'; $lnk.Save()"
echo Desktop shortcut created.
pause
