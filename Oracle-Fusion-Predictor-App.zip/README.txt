Oracle Fusion Predictor

How to open:
1. Double-click "Launch Oracle Fusion Predictor.bat".
2. Or open "index.html" directly in your browser.

Optional:
Double-click "Install Desktop Shortcut.bat" to add a desktop shortcut.

Data rule:
This app uses only Home odds, Draw odds, Away odds, and Final Score.
Under 0.5, Under 1.5, Over, and percentage columns are ignored.

Betting helper:
The KSh betting spot suggests SKIP or a stake from 1 to 50 shillings using confidence, upset risk, and Kelly edge.

Included data:
- 482 clean Home/Draw/Away/Score rows
- 482 score-derived outcome rows

Main app file:
index.html
